import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class returnVehicle {



     public static void main(String[] args){
         frame();
     }

     public static void frame(){
         DefaultTableModel model;

        JFrame f = new JFrame();

         f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         f.setLocationRelativeTo(null);

         f.getContentPane().setLayout(new GridBagLayout());
         GridBagConstraints gridConstraints = new GridBagConstraints();

         //Title
         JLabel title = new JLabel("Return Vehicle");
         title.setFont(new Font("Arial", Font.PLAIN, 25));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(10,0,30,0);
         f.getContentPane().add(title, gridConstraints);

         //Labels
         JLabel vehicleType = new JLabel("Name");
         vehicleType.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleType, gridConstraints);

         JLabel vehicleNumber = new JLabel("Vehicle Number");
         vehicleNumber.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleNumber, gridConstraints);

         JLabel vehicleManufacturer = new JLabel("Email");
         vehicleManufacturer.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleManufacturer, gridConstraints);

         JLabel vehicleModel = new JLabel("Charge per day");
         vehicleModel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleModel, gridConstraints);

         JLabel vehicleTransmission = new JLabel("Advanced");
         vehicleTransmission.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleTransmission, gridConstraints);
         
         JLabel issueDate = new JLabel("Issue Date");
         issueDate.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(issueDate, gridConstraints);
         
         JLabel balance = new JLabel("Balance");
         balance.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 7;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(balance, gridConstraints);


         //TextField
         JTextField text1 = new JTextField();
         text1.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text1, gridConstraints);

         JTextField text2 = new JTextField();
         text2.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text2, gridConstraints);

         JTextField text3 = new JTextField();
         text3.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text3, gridConstraints);

         JTextField text4 = new JTextField();
         text4.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text4, gridConstraints);

         JTextField text5 = new JTextField();
         text5.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text5, gridConstraints);
         
         JTextField text6 = new JTextField();
         text6.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text6, gridConstraints);
         
         JTextField text7 = new JTextField();
         text7.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 7;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text7, gridConstraints);

         //Buttons
         JButton addButton = new JButton("Rent");
         addButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(addButton, gridConstraints);


         JButton clear = new JButton("Clear");
         clear.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 2;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(clear, gridConstraints);
         
         

         JButton exit = new JButton("Exit");
         exit.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(exit, gridConstraints);




         f.setVisible(true);


         JTable table = new JTable ();

         table.setPreferredScrollableViewportSize(new Dimension(500, 200));
         table.setFillsViewportHeight(true);
         JScrollPane sp = new JScrollPane(table);
         model = new DefaultTableModel();
         Object[] column = {"Name", "Vehicle Number", "Email", "Charge", "Advance", "Issue Date", "Balance"};
         final Object[] row = new Object[7];
         model.setColumnIdentifiers(column);
         table.setModel(model);
         sp.setViewportView(table);
         
         
         //1st Table
         row[0] = "Joji";
         row[1] = "AHF-5436";
         row[2] = "joji@gmail.com";
         row[3] = "1000";
         row[4] = "3000";
         row[5] = "2022";
         row[6] = "TBD";
         

         model.addRow(row);
         
         //2nd Table
         row[0] = "Jonathan";
         row[1] = "PGI-4523";
         row[2] = "originaljoestar1@gmail.com";
         row[3] = "2000";
         row[4] = "6000";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         //3rd Table
         row[0] = "Joseph";
         row[1] = "JND-6848";
         row[2] = "thebestjoestar123@gmail.com";
         row[3] = "2500";
         row[4] = "7500";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         //4th Table
         row[0] = "Jotaro";
         row[1] = "ALK-4332";
         row[2] = "kujotaro@gmail.com";
         row[3] = "2000";
         row[4] = "6000";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         //5th Table
         row[0] = "Josuke";
         row[1] = "PFN-5973";
         row[2] = "diamondstand4@gmail.com";
         row[3] = "1000";
         row[4] = "3000";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         
         //6th Table
         row[0] = "Giorno";
         row[1] = "JGK-3212";
         row[2] = "sonofgod5@gmail.com";
         row[3] = "500";
         row[4] = "1500";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         //7th Table
         row[0] = "Jolyne";
         row[1] = "NKN-6546";
         row[2] = "freestoner66@gmail.com";
         row[3] = "1500";
         row[4] = "4500";
         row[5] = "2022";
         row[6] = "TBD";

         model.addRow(row);
         
         
         addButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 JFrame f = new JFrame();
                 /*

                 String typeOfCar = text1.getText();
                 String vehicleNumber = text2.getText();
                 String manufacturerOfCar = text3.getText();
                 String modelOfCar = text4.getText();
                 String transmissionOfCar = text5.getText();
                 String colorOfCar = text6.getText();
                 JOptionPane.showMessageDialog(null,"Renting\n","Vehicle Type: "+typeOfCar+ "\nVehicle Number"+vehicleNumber+ "\nManufacturer: "+manufacturerOfCar+
                "\nModel"+modelOfCar+"\nTransmission: "+transmissionOfCar+ "\nColor: "+colorOfCar );
                 */
                
                String t1 = text1.getText();
                String t2 = text2.getText();
                String t3 = text3.getText();
                String t4 = text4.getText();
                String t5 = text5.getText();
                String t6 = text6.getText();
                String t7 = text7.getText();
                
                //1st Row Table Validation
                if (t1.equals("Joji") && t2.equals("AHF-5436") && t3.equalsIgnoreCase("joji@gmail.com") && t4.equals("1000") && t5.equals("3000") && t6.equals("2022")){
                    
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }
                //2nd Row Table Validation
                else if (t1.equals("Jonathan") && t2.equals("PGI-4523") && t3.equalsIgnoreCase("originaljoestar1@gmail.com") && t4.equals("2000") && t5.equals("6000") && t6.equals("2022")){
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }               
                //3rd Row Table Validation
                else if (t1.equals("Joseph") && t2.equals("JND-6848") && t3.equalsIgnoreCase("thebestjoestar123@gmail.com") && t4.equals("2500") && t5.equals("7500") && t6.equals("2022")){
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }              
                //4th Row Table Validation
                else if (t1.equals("Jotaro") && t2.equals("ALK-4332") && t3.equalsIgnoreCase("kujotaro@gmail.com") && t4.equals("2000") && t5.equals("6000") && t6.equals("2022")){
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }
                //5th Row Table Validation
                else if (t1.equals("Josuke") && t2.equals("PFN-5973") && t3.equalsIgnoreCase("diamondstand4@gmail.com") && t4.equals("1000") && t5.equals("3000") && t6.equals("2022")){
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }
                //6th Row Table Validation
                else if (t1.equals("Giorno") && t2.equals("JGK-3212") && t3.equalsIgnoreCase("sonofgod5@gmail.com") && t4.equals("500") && t5.equals("1500") && t6.equals("2022")){
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nIssue Date: "+t6,"Reciept", 
                    JOptionPane.INFORMATION_MESSAGE );
                }
                JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5,"Reciept", 
                JOptionPane.INFORMATION_MESSAGE );
                
                
             }
         });

         
         clear.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                text1.setText(null);
                text2.setText(null);
                text3.setText(null);
                text4.setText(null);
                text5.setText(null);

             }
         });
         
         /*
         delete.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 
             }
         });
         */

         gridConstraints.gridx = 3;
         gridConstraints.gridy = 1;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp, gridConstraints);

         f.pack();


     }
}
